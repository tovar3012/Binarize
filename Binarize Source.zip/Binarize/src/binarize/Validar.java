package binarize;
import javax.swing.JLabel;
import javax.swing.JTextField;
public class Validar {
    
    int num;
    
    
    public boolean Validar_if_Caracter(JTextField txt, JLabel l){
    
        try{
        
            Integer.parseInt(txt.getText());
            l.setText(null);
            return true;
            
        }catch(NumberFormatException e){
            
            if( ! txt.getText().isEmpty()){
            l.setText("ERROR!, HAS DIGITADO LETRAS...");
            return false;
            }
          return false;
        }
        
    }//END VALIDAR_IF_CARACTER
    
    public boolean Validar_if_Binario(JTextField txt, JLabel l){
        
        try{
             num = Integer.parseInt(txt.getText(), 2);
             Integer.toBinaryString(num);
             return true;
        }catch (NumberFormatException e){
            l.setText("RECUERDA QUE BINARIOS SON SOLO 1 Y 0");
            return false;
        
        }
               
    }//END VALIDAR_IF_BINARIO
    
    public boolean Validar_if_OCTAL(JTextField txt, JLabel l){
        
        try{
            num = Integer.parseInt(txt.getText(), 8);
            Integer.toOctalString(num);
            return true;
        }catch (NumberFormatException e){
            l.setText("EL NUMERO DIGITADO NO ES UN OCTAL");
            return false;
        }
        
    }//END VALIDAR_IF_BINARIO
    
    public boolean Validar_if_HEXA(JTextField txt, JLabel l){
        
        try{
            num = Integer.parseInt(txt.getText(), 16);
            Integer.toHexString(num);
            l.setText(null);
            return true;
        }catch (NumberFormatException e){
            if( ! txt.getText().isEmpty()){
            l.setText("EL DATO DIGITADO NO ES UN HEXADECIMAL!");
            return false;
            }
          return false;
        }
        
    }//END VALIDAR_IF_HEXA
    
}//END CLASS
    

