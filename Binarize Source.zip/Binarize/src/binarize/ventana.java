package binarize;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ventana extends JFrame implements KeyListener{
    
    private final JFrame ventana = new JFrame();
    private JTextField txt1, txt2, txt3, txt4;
    private JLabel l1, l2, l3, l4, notify, title;
    private Font fuente_title;
    
    /*
    setBounds(X, Y, LARGO, ANCHO);
    */

    public ventana(){}
    
    public void PrintFrame(){
    
        ventana.setLayout(null);
        ventana.setBounds(200, 100, 500, 300);
        
        /* Creacion de las Fuentes */
        
        fuente_title = new Font("Arial", Font.BOLD, 20);
        
         // COMPONENTES Y POSICIONES EN X/Y
        
        title = new JLabel("BINARIZE CONVERTIDOR")
;       title.setBounds(120, 5, 350, 30);
        title.setForeground(Color.BLACK);
        title.setFont(fuente_title);
        
        l1 = new JLabel("BINARIO: ");
        l1.setBounds(45,49,60,30);
        
        txt1 = new JTextField();
        txt1.setBounds(120,50,300,25);
        txt1.addKeyListener( (KeyListener) this );
        
        l2 = new JLabel("OCTAL: ");
        l2.setBounds(50,90,60,30);
        
        txt2 = new JTextField();
        txt2.setBounds(120,90,300,25);
        txt2.addKeyListener( (KeyListener) this );
        
        l3 = new JLabel("DECIMAL: ");
        l3.setBounds(40,130,60,30);
        
        txt3 = new JTextField();
        txt3.setBounds(120,130,300,25);
        txt3.addKeyListener( (KeyListener) this );
        
        l4 = new JLabel("HEXADECIMAL: ");
        l4.setBounds(20,160,110,50);
        
        txt4 = new JTextField();
        txt4.setBounds(120,170,300,25);
        txt4.addKeyListener( (KeyListener) this );
        
        notify = new JLabel();
        notify.setBounds(20, 230, 300, 30);
        notify.setForeground(Color.RED);
        
        /*** AGREGA LOS COMPONENTES AL JFRAME***/
        
        ventana.add(title);
        
        ventana.add(l1);
        ventana.add(txt1);
        
        ventana.add(l2);
        ventana.add(txt2);
        
        ventana.add(l3);
        ventana.add(txt3);
        
        ventana.add(l4);
        ventana.add(txt4);
        
        ventana.add(notify);
        
        //PARA QUE EL BOTON CERRAR (IF) CIERRE EL PROGRAMA
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setVisible(true);
    
    }//END CONSTRUCTOR

    @Override
    /* EVENTO ACCIONADO AL PRESIONAR Y SOLTAR LAS TECLAS */
    public void keyTyped(KeyEvent ke) {
        //this.Conversor();
    }

    @Override
    /* EVENTO ACCIONADO AL PRESIONAR LAS TECLAS */
    public void keyPressed(KeyEvent ke) {
        //this.Conversor();
    }

    @Override
    /* EVENTO ACCIONADO AL SOLTAR LAS TECLAS */
    public void keyReleased(KeyEvent ke) {
        this.Conversor();
    }
    
    /* METODOS */
    
    Validar v = new Validar();
    
    private void Conversor(){
       
        int num;
        String num_final;
        
       if(this.txt1.hasFocus()){
           
        if(this.txt1.getText().isEmpty()){this.EstablecerTextos();}
         if(v.Validar_if_Caracter(this.txt1, this.notify) == true){
            if(v.Validar_if_Binario( this.txt1, this.notify)  == true){
            
            num = Integer.parseInt(this.txt1.getText(), 2);
                        
            //BINARIO A DECIMAL
            this.txt3.setText(""+num);
            
            //BINARIO A OCTAL
            num_final = Integer.toOctalString(num);
            this.txt2.setText(num_final);
            
            //BINARIO A HEXADECIMAL
            num_final = Integer.toHexString(num);
            this.txt4.setText( num_final.toUpperCase() );
            
            }//END VALIDAR_IF_BINARIO
         }//END VALIDAR_IF_CARACTER 
          
        }else if(this.txt2.hasFocus()){
          if(this.txt2.getText().isEmpty()){this.EstablecerTextos();}
            if(v.Validar_if_Caracter(this.txt2, this.notify)){
                if(v.Validar_if_OCTAL( this.txt2, this.notify)  == true){
                
            num = Integer.parseInt(this.txt2.getText(), 8);
            
            //OCTAL A BINARIO
            num_final = Integer.toBinaryString(num);
            this.txt1.setText( num_final );
            
            //OCTAL A HEXADECIMAL
            num_final = Integer.toHexString(num);
            this.txt4.setText( num_final );
            
            //OCTAL A DECIMAL
            num = Integer.parseInt(this.txt2.getText());
            this.txt3.setText(""+num);
            
           }//IF VALIDAR_IF_OCTAL
          }//IF VALIDAR_IF_CARACTER
            
        }else if(this.txt3.hasFocus()){
            if(this.txt3.getText().isEmpty()){this.EstablecerTextos();}
                    if(v.Validar_if_Caracter(this.txt3, this.notify)){
  
                num = Integer.parseInt(this.txt3.getText());
            
                //DECIMAL A BINARIO
                num_final = Integer.toBinaryString(num);
                this.txt1.setText( num_final );

                //DECIMAL A OCTAL
                num_final = Integer.toOctalString(num);
                this.txt2.setText( num_final );

                //DECIMAL A HEXADECIMAL
                num_final = Integer.toHexString(num);
                this.txt4.setText(num_final);
                
            }//IF VALIDAR
            
        }else if(this.txt4.hasFocus()){
            if(this.txt4.getText().isEmpty()){this.EstablecerTextos();}
                if(v.Validar_if_HEXA( this.txt4, this.notify)  == true){
                
                num = Integer.parseInt(this.txt4.getText(), 16);
            
                //HEXADECIMAL A BINARIO
                num_final = Integer.toBinaryString(num);
                this.txt1.setText( num_final );

                //HEXADECIMAL A OCTAL
                num_final = Integer.toOctalString(num);
                this.txt2.setText( num_final );

                //HEXADECIMAL A DECIMAL
                this.txt3.setText(""+num);
                
                }//IF VALIDAR_IF_HEXA
         
        }

       
    }//END METODO CONVERSOR

    public void EstablecerTextos(){
        this.txt1.setText(null);
        this.txt2.setText(null);
        this.txt3.setText(null);
        this.txt4.setText(null);
        this.notify.setText(null);
    }//END ESTABLECER TEXTOS
    
    
    
}//END CLASS
